export default {
  roots: ['test'],
};
